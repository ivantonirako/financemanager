package com.example.financemngr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;

import java.text.DecimalFormat;

public class TransactionDetailsActivity extends AppCompatActivity {

    private static final DecimalFormat df = new DecimalFormat("0.00");
    EditText titleEditText, contentEditText;
    ImageButton saveTransactionBtn;
    TextView pageTitleTextView;
    String title, docId;
    double content;
    boolean isEditMode = false;
    TextView deleteTransactionTextViewBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_details);

        titleEditText = findViewById(R.id.transactions_title_text);
        contentEditText = findViewById(R.id.transactions_content_text);
        saveTransactionBtn = findViewById(R.id.save_transaction_btn);
        pageTitleTextView = findViewById(R.id.page_title);
        deleteTransactionTextViewBtn = findViewById(R.id.delete_transaction_text_view_btn);

        title = getIntent().getStringExtra("title");
        content = getIntent().getDoubleExtra("content", 0);
        docId = getIntent().getStringExtra("docId");

        contentEditText.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(7, 2)});

        if (docId != null && !docId.isEmpty()){
            isEditMode = true;
        }

        titleEditText.setText(title);
        contentEditText.setText(String.valueOf(content));

        if (isEditMode){
            pageTitleTextView.setText("Edit transaction");
            deleteTransactionTextViewBtn.setVisibility(View.VISIBLE);
        }

        saveTransactionBtn.setOnClickListener((v)-> saveTransaction());
        deleteTransactionTextViewBtn.setOnClickListener((v)->deleteNoteFromFirebase());
    }

    void saveTransaction() {
        String transactionTitle = titleEditText.getText().toString();
        String transactionContent = contentEditText.getText().toString();
        if (transactionTitle.isEmpty()) {
            titleEditText.setError("Title is required");
            return;
        }
        if (transactionContent.isEmpty()) {
            contentEditText.setError("Amount is required");
            return;
        }

        // Validate transaction amount
        try {
            double amount = Double.parseDouble(transactionContent);
            if (amount <= 0) {
                contentEditText.setError("Amount must be greater than zero");
                return;
            }
            if (amount > 1000000) {
                contentEditText.setError("Amount too large");
                return;
            }
        } catch (NumberFormatException e) {
            contentEditText.setError("Invalid amount");
            return;
        }

        // Proceed with saving the transaction
        Transaction transaction = new Transaction();
        transaction.setTitle(transactionTitle);

        // Format amount to ensure consistent decimal format
        double amount = Double.parseDouble(df.format(Double.parseDouble(transactionContent)));

        transaction.setContent(amount);
        transaction.setTimestamp(Timestamp.now());

        saveTransactionToFirebase(transaction);
    }

    void saveTransactionToFirebase(Transaction transaction){
        DocumentReference documentReference;
        if (isEditMode){
            documentReference = Utility.getCollectionReferenceForTransactions().document(docId);
        }else{
            documentReference = Utility.getCollectionReferenceForTransactions().document();
        }

        documentReference.set(transaction).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Utility.showToast(TransactionDetailsActivity.this, "Transaction added successfully");
                    finish();
                }else{
                    Utility.showToast(TransactionDetailsActivity.this, "Failed adding transaction");
                }
            }
        });
    }

    void deleteNoteFromFirebase(){
        DocumentReference documentReference;
        documentReference = Utility.getCollectionReferenceForTransactions().document(docId);

        documentReference.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Utility.showToast(TransactionDetailsActivity.this, "Transaction deleted successfully");
                    finish();
                }else{
                    Utility.showToast(TransactionDetailsActivity.this, "Failed deleting transaction");
                }
            }
        });
    }
}