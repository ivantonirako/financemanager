package com.example.financemngr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.Query;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton addTransactionBtn;
    TextView tvsum;
    RecyclerView recyclerView;
    ImageButton menuBtn;
    TransactionAdapter transactionAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addTransactionBtn = findViewById(R.id.add_transaction_btn);
        recyclerView = findViewById(R.id.recyler_view);
        menuBtn = findViewById(R.id.menu_btn);
        tvsum = findViewById(R.id.tvsum);

        addTransactionBtn.setOnClickListener((v) -> startActivity(new Intent(MainActivity.this, TransactionDetailsActivity.class)));
        menuBtn.setOnClickListener((v) -> showMenu());
        setupRecyclerView();
    }

    void showMenu(){
        PopupMenu popupMenu = new PopupMenu(MainActivity.this, menuBtn);
        popupMenu.getMenu().add("Logout");
        popupMenu.show();
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (menuItem.getTitle()=="Logout"){
                    FirebaseAuth.getInstance().signOut();
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                    return true;
                }
                return false;
            }
        });
    }

    void setupRecyclerView() {
        Query query = Utility.getCollectionReferenceForTransactions().orderBy("timestamp", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<Transaction> options = new FirestoreRecyclerOptions.Builder<Transaction>()
                .setQuery(query, Transaction.class).build();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        transactionAdapter = new TransactionAdapter(options, this);
        recyclerView.setAdapter(transactionAdapter);

        calculateAndDisplayTotalSum();
    }

    void calculateAndDisplayTotalSum() {
        Query query = Utility.getCollectionReferenceForTransactions().orderBy("timestamp", Query.Direction.DESCENDING);
        query.get().addOnSuccessListener(queryDocumentSnapshots -> {
            double totalSum = 0;
            for (DocumentSnapshot document : queryDocumentSnapshots) {
                Transaction transaction = document.toObject(Transaction.class);
                if (transaction != null) {
                    totalSum += transaction.getContent();
                }
            }

            // Check if the total sum exceeds 1000000
            if (totalSum > 1000000) {
                tvsum.setText("Sum too large");
            } else {
                // Create a DecimalFormat object with a specific format pattern
                DecimalFormat df = new DecimalFormat("#,##0.00"); // Adjust the format pattern as needed
                String totalSumFormatted = df.format(totalSum);

                // Update TextView with formatted total sum
                String totalSumString = "Total amount: " + totalSumFormatted + " €";
                tvsum.setText(totalSumString);
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(MainActivity.this, "Failed to fetch transactions", Toast.LENGTH_SHORT).show();
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        transactionAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        transactionAdapter.stopListening();
    }

    @Override
    protected void onResume() {
        super.onResume();
        transactionAdapter.notifyDataSetChanged();
        calculateAndDisplayTotalSum();
    }
}