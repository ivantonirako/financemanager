package com.example.financemngr;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import java.text.DecimalFormat;
import java.util.List;

public class TransactionAdapter extends FirestoreRecyclerAdapter<Transaction, TransactionAdapter.TransactionViewHolder> {
    Context context;

    public TransactionAdapter(@NonNull FirestoreRecyclerOptions<Transaction> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull TransactionViewHolder holder, int position, @NonNull Transaction transaction) {
        holder.titleTextView.setText(transaction.getTitle());

        // Format the content of the transaction
        DecimalFormat df = new DecimalFormat("#,##0.00");
        String formattedContent = df.format(transaction.getContent());

        // Concatenate the euro symbol with the formatted content
        String displayContent = formattedContent + " €";

        holder.contentTextView.setText(displayContent);
        holder.timestampTextView.setText(Utility.timestampToString(transaction.getTimestamp()));

        holder.itemView.setOnClickListener((v) -> {
            Intent intent = new Intent(context, TransactionDetailsActivity.class);
            intent.putExtra("title", transaction.getTitle());
            intent.putExtra("content", transaction.getContent());
            String docId = getSnapshots().getSnapshot(position).getId();
            intent.putExtra("docId", docId);
            context.startActivity(intent);
        });
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_transaction_item, parent, false);
        return new TransactionViewHolder(view);
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, contentTextView, timestampTextView;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.transaction_title_text_view);
            contentTextView = itemView.findViewById(R.id.transaction_content_text_view);
            timestampTextView = itemView.findViewById(R.id.transaction_timestamp_text_view);
        }
    }
}